______________________________
Opossum Massage Simulator N64
______________________________
Version 2.0
An original game by DJ Omnimaga (It RPG ls!), recreated and ported by gameblabla

Opossum Massage Simulator is the ULTIMATE massage simulator of opossums !
Massage it and survive as long as possible !

The game has 2 modes : Linear Mode and Mood Mode.

In Linear, the game becomes gradually difficult.
In Mood mode, the possum changes its mood randomly after a certain amount of time.

Sound effects were done by jalastram.
http://freesound.org/people/jalastram/

_________
Controls
_________

A = Massage
START = Start the game

_________
CHANGELOG
_________

Version 2.0 :
Initial version was not working on real hardware. Now fixed
