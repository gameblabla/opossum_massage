__________________________
Opossum Massage Simulator
__________________________
Version 1.2
For TI Nspire CX
An original game by DJ Omnimaga (It RPG ls!), recreated and ported by gameblabla

Opossum Massage Simulator is the ULTIMATE massage simulator of opossums !
Massage it and survive as long as possible !

The game has 2 modes : Linear Mode and Mood Mode.

In Linear, the game becomes gradually difficult.
In Mood mode, the possum changes its mood randomly after a certain amount of time.

Sound effects were done by jalastram.
http://freesound.org/people/jalastram/

_________
Controls
_________

CTRL = Massage
MENU = Start the game
ESC  = Quit the game at any time

_________
CHANGELOG
_________

Version 1.2 :
New text font.
The story was also slightly edited.

Version 1.1 :
DJ Omnimaga has finally released the game for TI-84 CSE !
His version was inspired by my version based on the incomplete prototype
but he changed the gameplay a bit, which is now based on the possum's mood.

I have added two game modes : Linear Mode and Mood Mode.